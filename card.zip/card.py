# 데이터 프레임 생성을 위한 라이브러리
import pandas as pd

# 시각화를 위한 라이브러리
import matplotlib.pyplot as plt
plt.rc('font', family='NanumGothic')

from google.colab import drive
drive.mount('/content/drive')

from google.colab import drive
drive.mount('/content/drive')

df1=pd.read_csv(BASE_DIR+'/블록별 성별연령대별 카드소비패턴.csv', encoding='cp949')
#df1


def change_age(text:str):
    return text[:2]

df1['연령대별(AGE)'] = df1['연령대별(AGE)'].map(change_age).astype(int)
#
# df1


# 이용 건수

x = df1.groupby(by='성별(GEDNER)').sum().index
y = df1.groupby(by='성별(GEDNER)').sum()['카드이용건수계(USECT_CORR)']
plt.title('gender vs usect')
plt.xlabel('gender')
plt.ylabel('usect')
plt.pie(y, labels=x.values)
#plt.legend()
#plt.show()


# 이용 금액

x = df1.groupby(by='성별(GEDNER)').sum().index
y = df1.groupby(by='성별(GEDNER)').sum()['카드이용금액계(AMT_CORR)']
plt.title('gender vs amt')
plt.xlabel('gender')
plt.ylabel('amt')
plt.pie(y, labels=x.values)
#plt.legend()
#plt.show()

x = df1.groupby(by='연령대별(AGE)').sum().index
y = df1.groupby(by='연령대별(AGE)').sum()['카드이용건수계(USECT_CORR)']
plt.title('age vs usect')
plt.xlabel('age')
plt.ylabel('usect')
#plt.plot(x,y)
#plt.show()


x = df1.groupby(by='연령대별(AGE)').sum().index
y = df1.groupby(by='연령대별(AGE)').sum()['카드이용건수계(USECT_CORR)']
plt.title('age vs usect')
plt.xlabel('age')
plt.ylabel('usect')
plt.plot(x,y)
#plt.show()


x = df1.groupby(by='연령대별(AGE)').sum().index
y = df1.groupby(by='연령대별(AGE)').sum()['카드이용금액계(AMT_CORR)']
plt.title('age vs amt')
plt.xlabel('age')
plt.ylabel('amt')
plt.plot(x,y)
#plt.show()


